
import React from 'react';
import { motion } from 'framer-motion';
import { SOCIAL_LINKS } from '../constants';

interface SocialLinksProps {
  onEmailClick: () => void;
  onWhatsappClick: () => void;
  theme: 'dark' | 'light';
}

const SocialLinks: React.FC<SocialLinksProps> = ({ onEmailClick, onWhatsappClick, theme }) => {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.5
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0, scale: 0.8 },
    show: { y: 0, opacity: 1, scale: 1 }
  };

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-8 max-w-5xl mx-auto px-6"
    >
      {SOCIAL_LINKS.map((link, index) => (
        <motion.a
          key={link.id}
          href={link.id === 'email' || link.id === 'whatsapp' ? undefined : link.url}
          target={link.id === 'email' || link.id === 'whatsapp' ? undefined : "_blank"}
          rel="noopener noreferrer"
          variants={item}
          onClick={(e) => {
            if (link.id === 'email') {
              e.preventDefault();
              onEmailClick();
            } else if (link.id === 'whatsapp') {
              e.preventDefault();
              onWhatsappClick();
            }
          }}
          whileHover={{ 
            scale: 1.1, 
            rotate: index % 2 === 0 ? 5 : -5,
            transition: { duration: 0.2 } 
          }}
          whileTap={{ scale: 0.95 }}
          className={`group relative flex flex-col items-center justify-center aspect-square rounded-3xl backdrop-blur-xl p-6 transition-all duration-300 cursor-pointer border ${
            theme === 'dark' 
              ? 'bg-slate-900/40 border-slate-800 hover:border-blue-500/50' 
              : 'bg-white border-slate-200 hover:border-blue-500 shadow-sm hover:shadow-xl'
          }`}
        >
          {/* Animated Background Gradient on Hover */}
          <div className={`absolute inset-0 opacity-0 group-hover:opacity-10 rounded-3xl transition-opacity duration-300 bg-gradient-to-br ${link.gradient}`}></div>
          
          <div className={`p-4 rounded-2xl group-hover:text-white group-hover:shadow-[0_0_20px_rgba(255,255,255,0.2)] transition-all duration-300 ${
            theme === 'dark' 
              ? 'bg-slate-800 text-slate-300' 
              : 'bg-slate-100 text-slate-600'
          } group-hover:bg-gradient-to-br ${link.gradient}`}>
            {link.icon}
          </div>
          
          <span className={`mt-4 font-bold transition-colors tracking-wide ${
            theme === 'dark' ? 'text-slate-400 group-hover:text-white' : 'text-slate-500 group-hover:text-slate-900'
          }`}>
            {link.name}
          </span>

          {/* Floating dot */}
          <motion.div 
            animate={{ 
              opacity: [0, 1, 0],
              y: [0, -10, 0]
            }}
            transition={{ 
              duration: 2, 
              repeat: Infinity, 
              delay: Math.random() * 2 
            }}
            className={`absolute top-2 right-2 w-1.5 h-1.5 rounded-full shadow-[0_0_8px_${link.color}]`}
            style={{ backgroundColor: link.color }}
          />
        </motion.a>
      ))}
    </motion.div>
  );
};

export default SocialLinks;
