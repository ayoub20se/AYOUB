
import React from 'react';
import { motion } from 'framer-motion';
import { GALLERY_IMAGES } from '../constants';

const ImageGallery: React.FC = () => {
  return (
    <section className="w-full max-w-7xl mx-auto px-6 mt-32 mb-20">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-12"
      >
        <h2 className="text-3xl md:text-5xl font-black text-white mb-4">
          Visual <span className="text-blue-500 italic">Showcase</span>
        </h2>
        <div className="w-24 h-1 bg-blue-600 mx-auto rounded-full"></div>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {GALLERY_IMAGES.map((image, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ y: -10 }}
            className="group relative aspect-[4/3] overflow-hidden rounded-3xl bg-slate-900 border border-slate-800"
          >
            {/* Overlay Gradient */}
            <div className="absolute inset-0 z-10 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            
            {/* Image */}
            <motion.img 
              src={image.url} 
              alt={image.title}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />

            {/* Content Overlay */}
            <div className="absolute inset-x-0 bottom-0 z-20 p-8 transform translate-y-6 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-500">
              <p className="text-blue-400 text-xs font-bold uppercase tracking-[0.3em] mb-2">Collection</p>
              <h4 className="text-white text-2xl font-black">{image.title}</h4>
            </div>

            {/* Glowing Border effect */}
            <div className="absolute inset-0 border-2 border-blue-500/0 group-hover:border-blue-500/30 rounded-3xl transition-colors duration-500" />
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default ImageGallery;
