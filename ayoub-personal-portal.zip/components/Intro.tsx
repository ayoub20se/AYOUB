
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

interface IntroProps {
  onComplete: () => void;
  welcomeText: string;
  theme: 'dark' | 'light';
}

const Intro: React.FC<IntroProps> = ({ onComplete, welcomeText, theme }) => {
  const name = "AYOUB";
  const nameLetters = name.split("");
  const [isGathered, setIsGathered] = useState(false);

  useEffect(() => {
    // Stage 1: Wave for 3 seconds, then gather
    const gatherTimer = setTimeout(() => setIsGathered(true), 3000);
    
    // Stage 2: Final transition to app
    const completeTimer = setTimeout(() => {
      onComplete();
    }, 6000);
    
    return () => {
      clearTimeout(gatherTimer);
      clearTimeout(completeTimer);
    };
  }, [onComplete]);

  return (
    <div className={`fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden transition-colors duration-700 ${theme === 'dark' ? 'bg-slate-950' : 'bg-slate-50'}`}>
      <div className="relative flex flex-col items-center">
        {/* Wavy Name Animation */}
        <div className="flex space-x-2 md:space-x-4 mb-8">
          {nameLetters.map((letter, index) => (
            <motion.span
              key={index}
              initial={{ y: 0, opacity: 0 }}
              animate={isGathered ? {
                y: 0,
                opacity: 1,
                scale: 1,
                filter: "blur(0px)",
              } : {
                y: [0, -40, 0],
                opacity: [0, 1, 0.5],
                scale: [1, 1.2, 1],
              }}
              transition={isGathered ? {
                duration: 0.8,
                ease: "easeOut",
                delay: index * 0.05
              } : {
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
                delay: index * 0.2
              }}
              className={`text-6xl md:text-9xl font-black drop-shadow-[0_0_20px_rgba(59,130,246,0.3)] ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}
            >
              {letter}
            </motion.span>
          ))}
        </div>

        {/* Welcome Text Subtitle */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isGathered ? { opacity: 1, y: 0 } : { opacity: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="text-center"
        >
          <p className={`text-xl md:text-3xl font-light uppercase tracking-[0.4em] ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`}>
            {welcomeText}
          </p>
          <motion.div 
            initial={{ scaleX: 0 }}
            animate={isGathered ? { scaleX: 1 } : { scaleX: 0 }}
            transition={{ duration: 1.5, delay: 0.8 }}
            className={`h-px bg-gradient-to-r from-transparent via-blue-500 to-transparent mt-4 w-64 mx-auto`}
          />
        </motion.div>
      </div>

      {/* Subtle Background Glow */}
      <motion.div 
        animate={{ 
          opacity: [0.1, 0.2, 0.1],
          scale: [1, 1.1, 1]
        }}
        transition={{ duration: 4, repeat: Infinity }}
        className={`absolute w-[500px] h-[500px] blur-[120px] rounded-full -z-10 ${theme === 'dark' ? 'bg-blue-600/20' : 'bg-blue-400/10'}`}
      />
    </div>
  );
};

export default Intro;
