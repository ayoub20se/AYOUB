
import React from 'react';
import { motion } from 'framer-motion';

interface KnowledgeWidgetProps {
  theme: 'dark' | 'light';
}

const KnowledgeWidget: React.FC<KnowledgeWidgetProps> = ({ theme }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`relative group p-4 md:p-6 rounded-[2.5rem] border backdrop-blur-xl shadow-xl transition-all duration-500 w-full max-w-[300px] md:max-w-[350px] mx-auto ${
        theme === 'dark' 
          ? 'bg-slate-900/40 border-slate-800 shadow-amber-900/10 hover:border-amber-500/30' 
          : 'bg-white/90 border-slate-200 shadow-slate-200 hover:border-amber-400/50'
      }`}
    >
      {/* Animated Background Glow */}
      <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-orange-500/5 rounded-[2.5rem] -z-10 group-hover:opacity-100 opacity-0 transition-opacity duration-700" />
      
      <div className="flex flex-col items-center gap-3 font-arabic text-center">
        {/* Bismillah */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className={`text-xs md:text-sm font-medium opacity-80 ${
            theme === 'dark' ? 'text-amber-200/60' : 'text-amber-700/60'
          }`}
        >
          بسم الله الرحمن الرحيم
        </motion.p>

        {/* Main Ayat */}
        <motion.h3
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.4, type: "spring" }}
          className={`text-xl md:text-2xl font-black leading-relaxed tracking-wide py-1 ${
            theme === 'dark' 
              ? 'text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400' 
              : 'text-transparent bg-clip-text bg-gradient-to-r from-amber-600 to-orange-600'
          }`}
        >
          وَقُل رَّبِّ زِدْنِي عِلْمًا
        </motion.h3>

        {/* Sadaqallahul-Azim */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className={`text-xs md:text-sm font-medium opacity-80 italic ${
            theme === 'dark' ? 'text-amber-200/60' : 'text-amber-700/60'
          }`}
        >
          صدق الله العظيم
        </motion.p>
      </div>

      {/* Decorative Elements */}
      <div className={`absolute top-4 right-4 w-1.5 h-1.5 rounded-full ${theme === 'dark' ? 'bg-amber-500/20' : 'bg-amber-400/20'}`} />
      <div className={`absolute bottom-4 left-4 w-1.5 h-1.5 rounded-full ${theme === 'dark' ? 'bg-orange-500/20' : 'bg-orange-400/20'}`} />
      
      {/* Corner Ornaments */}
      <div className={`absolute top-0 right-0 p-2 opacity-20 ${theme === 'dark' ? 'text-amber-500' : 'text-amber-600'}`}>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2 4 4 2-4 2-2 4-2-4-4-2 4-2z"/></svg>
      </div>
    </motion.div>
  );
};

export default KnowledgeWidget;
