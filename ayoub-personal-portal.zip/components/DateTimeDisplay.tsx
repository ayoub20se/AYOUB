
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

interface DateTimeDisplayProps {
  theme: 'dark' | 'light';
  lang: string;
}

const DateTimeDisplay: React.FC<DateTimeDisplayProps> = ({ theme, lang }) => {
  const [time, setTime] = useState(new Date());
  const ALGERIA_TIMEZONE = 'Africa/Algiers';

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatGregorian = () => {
    return new Intl.DateTimeFormat(lang, {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      timeZone: ALGERIA_TIMEZONE
    }).format(time);
  };

  const formatHijri = () => {
    return new Intl.DateTimeFormat(lang + '-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      timeZone: ALGERIA_TIMEZONE
    }).format(time);
  };

  const formatTime = () => {
    const options: Intl.DateTimeFormatOptions = {
      timeZone: ALGERIA_TIMEZONE,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    };
    
    // Using 'en-GB' to ensure 24h parts are extracted correctly
    const formatter = new Intl.DateTimeFormat('en-GB', options);
    const parts = formatter.formatToParts(time);
    
    const hours = parts.find(p => p.type === 'hour')?.value || '00';
    const minutes = parts.find(p => p.type === 'minute')?.value || '00';
    const seconds = parts.find(p => p.type === 'second')?.value || '00';
    
    return { hours, minutes, seconds };
  };

  const { hours, minutes, seconds } = formatTime();

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className={`relative group p-4 md:p-5 rounded-3xl border backdrop-blur-xl shadow-xl transition-all duration-500 w-full max-w-[280px] md:max-w-[320px] ${
        theme === 'dark' 
          ? 'bg-slate-900/40 border-slate-800 shadow-blue-900/10 hover:border-blue-500/30' 
          : 'bg-white/90 border-slate-200 shadow-slate-200 hover:border-blue-400/50'
      }`}
    >
      {/* Animated Background Glow */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-cyan-500/5 rounded-3xl -z-10 group-hover:opacity-100 opacity-0 transition-opacity duration-700" />
      
      <div className="flex flex-col items-center gap-3">
        {/* Dates Section */}
        <div className="text-center space-y-0.5">
          <motion.p 
            key={formatGregorian()}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={`text-xs font-medium tracking-wide ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}
          >
            {formatGregorian()}
          </motion.p>
          <motion.p 
            key={formatHijri()}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={`text-sm md:text-base font-arabic font-bold ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`}
          >
            {formatHijri()}
          </motion.p>
        </div>

        {/* Separator Line */}
        <div className={`h-px w-16 bg-gradient-to-r from-transparent via-blue-500/20 to-transparent`} />

        {/* Time Section */}
        <div className="flex flex-col items-center">
          <div className="flex items-center gap-2 md:gap-3 font-mono">
            <TimeUnit value={hours} label="H" theme={theme} />
            <Separator theme={theme} />
            <TimeUnit value={minutes} label="M" theme={theme} />
            <Separator theme={theme} />
            <TimeUnit value={seconds} label="S" theme={theme} isPulse />
          </div>
          <span className={`text-[9px] mt-1 font-bold uppercase tracking-widest ${theme === 'dark' ? 'text-blue-500/50' : 'text-blue-400'}`}>
            Algeria Time
          </span>
        </div>
      </div>
      
      {/* Subtle Corner Accents */}
      <div className={`absolute top-2 right-2 w-1 h-1 rounded-full ${theme === 'dark' ? 'bg-blue-500/30' : 'bg-blue-400/30'}`} />
      <div className={`absolute bottom-2 left-2 w-1 h-1 rounded-full ${theme === 'dark' ? 'bg-cyan-500/30' : 'bg-cyan-400/30'}`} />
    </motion.div>
  );
};

const TimeUnit: React.FC<{ value: string; label: string; theme: 'dark' | 'light'; isPulse?: boolean }> = ({ value, label, theme, isPulse }) => (
  <div className="flex flex-col items-center">
    <motion.div 
      key={value}
      initial={{ scale: 0.9 }}
      animate={{ scale: 1 }}
      className={`text-2xl md:text-3xl font-black tabular-nums transition-colors ${
        theme === 'dark' ? 'text-white' : 'text-slate-900'
      } ${isPulse ? 'text-blue-500' : ''}`}
    >
      {value}
    </motion.div>
    <span className={`text-[8px] uppercase tracking-tighter font-bold ${theme === 'dark' ? 'text-slate-600' : 'text-slate-400'}`}>
      {label}
    </span>
  </div>
);

const Separator: React.FC<{ theme: 'dark' | 'light' }> = ({ theme }) => (
  <div className={`text-xl md:text-2xl font-bold self-start mt-0.5 md:mt-1 ${theme === 'dark' ? 'text-slate-800' : 'text-slate-200'}`}>:</div>
);

export default DateTimeDisplay;
