
import React from 'react';
import { motion } from 'framer-motion';

interface DhikrWidgetProps {
  theme: 'dark' | 'light';
}

const DhikrWidget: React.FC<DhikrWidgetProps> = ({ theme }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className={`relative group p-4 md:p-5 rounded-3xl border backdrop-blur-xl shadow-xl transition-all duration-500 w-full max-w-[280px] md:max-w-[320px] mt-4 ${
        theme === 'dark' 
          ? 'bg-slate-900/40 border-slate-800 shadow-blue-900/10 hover:border-emerald-500/30' 
          : 'bg-white/90 border-slate-200 shadow-slate-200 hover:border-emerald-400/50'
      }`}
    >
      {/* Animated Background Glow */}
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-teal-500/5 rounded-3xl -z-10 group-hover:opacity-100 opacity-0 transition-opacity duration-700" />
      
      <div className="flex flex-col items-center gap-3 font-arabic text-center">
        {/* Main Dhikr Row */}
        <div className="flex flex-wrap justify-center gap-x-4 gap-y-1">
          <DhikrItem text="استغفر الله" theme={theme} delay={0.1} />
          <DhikrItem text="الحمد لله" theme={theme} delay={0.2} />
          <DhikrItem text="الله أكبر" theme={theme} delay={0.3} />
        </div>

        {/* Separator */}
        <div className={`h-px w-20 bg-gradient-to-r from-transparent via-emerald-500/20 to-transparent`} />

        {/* Salawat Section */}
        <motion.p
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className={`text-sm md:text-base font-bold leading-relaxed ${
            theme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'
          }`}
        >
          اللهم صلي و سلم على سيدنا محمد
        </motion.p>
      </div>

      {/* Subtle Corner Accents */}
      <div className={`absolute top-2 left-2 w-1 h-1 rounded-full ${theme === 'dark' ? 'bg-emerald-500/30' : 'bg-emerald-400/30'}`} />
      <div className={`absolute bottom-2 right-2 w-1 h-1 rounded-full ${theme === 'dark' ? 'bg-teal-500/30' : 'bg-teal-400/30'}`} />
    </motion.div>
  );
};

const DhikrItem: React.FC<{ text: string; theme: 'dark' | 'light'; delay: number }> = ({ text, theme, delay }) => (
  <motion.span
    initial={{ opacity: 0, scale: 0.9 }}
    animate={{ opacity: 1, scale: 1 }}
    transition={{ delay }}
    whileHover={{ scale: 1.05 }}
    className={`text-base md:text-lg font-bold cursor-default transition-colors ${
      theme === 'dark' ? 'text-white hover:text-emerald-400' : 'text-slate-900 hover:text-emerald-600'
    }`}
  >
    {text}
  </motion.span>
);

export default DhikrWidget;
